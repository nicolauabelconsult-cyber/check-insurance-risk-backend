from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import os

# ---------- CONFIG ----------

API_TITLE = "Check Insurance Risk API"
API_VERSION = "2.0"

# Ajusta esta lista depois do deploy do frontend no Netlify
ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "https://check-insurance-risk-frontend.netlify.app",
    "https://app.netlify.app",
    "*"
]

REPORTS_DIR = os.path.join(os.path.dirname(__file__), "static_reports")
os.makedirs(REPORTS_DIR, exist_ok=True)

# ---------- APP SETUP ----------

app = FastAPI(title=API_TITLE, version=API_VERSION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- AUTH MOCK ----------

class LoginRequest(BaseModel):
    username: str
    password: str

class UserInfo(BaseModel):
    id: int
    full_name: str
    role: str

class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str
    expires_in: int
    user: UserInfo

def fake_auth(username: str, password: str) -> Optional[LoginResponse]:
    # MVP: login fixo "admin" / "1234"
    if username == "admin" and password == "1234":
        return LoginResponse(
            access_token="mock_access_token",
            refresh_token="mock_refresh_token",
            token_type="bearer",
            expires_in=900,
            user=UserInfo(
                id=1,
                full_name="Administrador",
                role="admin"
            )
        )
    return None

@app.post("/api/login", response_model=LoginResponse)
def login(body: LoginRequest):
    auth = fake_auth(body.username, body.password)
    if not auth:
        raise HTTPException(status_code=401, detail="Credenciais inválidas")
    return auth


# ---------- RISK CHECK MOCK ----------

class RiskCheckRequest(BaseModel):
    subject_name: str
    subject_doc_id: str
    subject_type: str
    extra_info: Optional[dict] = None

class PepMatch(BaseModel):
    source: str
    name: str
    confidence: float

class SanctionMatch(BaseModel):
    list: str
    name: str
    confidence: float

class RiskCheckResponse(BaseModel):
    risk_request_id: int
    score: float
    risk_level: str
    pep_matches: List[PepMatch]
    sanctions_matches: List[SanctionMatch]
    red_flags: List[str]

@app.post("/api/risk-check", response_model=RiskCheckResponse)
def risk_check(body: RiskCheckRequest):
    # Mock de cálculo de risco / PEP / sanções
    # Em produção: aqui ligarás bases PEP e listas de sanções OFAC/ONU/etc.
    example_id = 981

    score = 72.5
    level = "ALTO"

    resp = RiskCheckResponse(
        risk_request_id=example_id,
        score=score,
        risk_level=level,
        pep_matches=[
            PepMatch(
                source="PEP_DB",
                name=body.subject_name,
                confidence=0.91
            )
        ],
        sanctions_matches=[
            SanctionMatch(
                list="OFAC",
                name=body.subject_name,
                confidence=0.78
            )
        ],
        red_flags=[
            "Exposição política (PEP)",
            "Match parcial em lista de sanções internacionais"
        ]
    )
    return resp


# ---------- REPORT GENERATION MOCK ----------

class ReportGenRequest(BaseModel):
    risk_request_id: int
    format: str = "pdf"

class ReportGenResponse(BaseModel):
    risk_request_id: int
    report_type: str
    format: str
    download_url: str
    generated_at: str

@app.post("/api/generate-report", response_model=ReportGenResponse)
def generate_report(body: ReportGenRequest):
    # No MVP vamos devolver um PDF estático pronto para download.
    # O frontend espera campo download_url.
    filename = f"{body.risk_request_id}_premium_v3.pdf"
    file_path = os.path.join(REPORTS_DIR, filename)

    # Se não existir ainda um PDF específico para este ID,
    # vamos apenas copiar sample.pdf como placeholder.
    sample_path = os.path.join(REPORTS_DIR, "sample.pdf")
    if os.path.exists(sample_path) and not os.path.exists(file_path):
        with open(sample_path, "rb") as src, open(file_path, "wb") as dst:
            dst.write(src.read())

    download_url = f"/files/reports/{filename}"

    return ReportGenResponse(
        risk_request_id=body.risk_request_id,
        report_type="Premium v3",
        format=body.format,
        download_url=download_url,
        generated_at=datetime.utcnow().isoformat() + "Z"
    )


# ---------- REPORT FILE DELIVERY ----------

@app.get("/files/reports/{report_name}")
def download_report_file(report_name: str):
    file_path = os.path.join(REPORTS_DIR, report_name)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Relatório não encontrado")
    return FileResponse(
        path=file_path,
        media_type="application/pdf",
        filename=report_name
    )


# ---------- HEALTHCHECK ----------

@app.get("/")
def root():
    return {"status": "ok", "service": API_TITLE, "version": API_VERSION}
