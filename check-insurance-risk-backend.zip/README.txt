CHECK INSURANCE RISK - BACKEND (FastAPI)

Endpoints principais:
- POST /api/login
  body: { "username": "admin", "password": "1234" }
  devolve: access_token mock + dados do utilizador

- POST /api/risk-check
  body: {
    "subject_name": "...",
    "subject_doc_id": "...",
    "subject_type": "individual"
  }
  devolve: score, nível de risco, flags PEP/sanções

- POST /api/generate-report
  body: { "risk_request_id": 981, "format": "pdf" }
  devolve: { download_url: "/files/reports/981_premium_v3.pdf", ... }

- GET /files/reports/{ficheiro.pdf}
  devolve o PDF (placeholder)

Para executar localmente:
1. python -m venv venv && source venv/bin/activate
2. pip install -r requirements.txt
3. python -c "import os; os.environ['PORT']='8000'; import uvicorn; uvicorn.run('main:app',host='0.0.0.0',port=8000)"
   ou: bash run.sh (num ambiente tipo Render)

IMPORTANTE:
- A pasta static_reports contém um sample.pdf usado como placeholder de relatório Premium v3.
- No Render:
  Root Directory = (a raiz deste ZIP)
  Build Command  = pip install -r requirements.txt
  Start Command  = bash run.sh
