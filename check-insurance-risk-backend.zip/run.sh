#!/bin/bash
# Script de arranque para Render
# Usa uvicorn para servir a API FastAPI em produção
# Render disponibiliza a porta na variável $PORT

echo "Starting Uvicorn on 0.0.0.0:${PORT:-10000} ..."

uvicorn main:app   --host 0.0.0.0   --port ${PORT:-10000}   --log-level info
